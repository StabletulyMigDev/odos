function exit() {
	window.close();
 }

function login() {
	window.location.href = '../system16/finder/fin.html';
 }